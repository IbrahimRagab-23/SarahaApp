import { Router } from "express";
import { succsseResponse } from "../../common/utils/index.js";
import { login, signup } from "./Authentiction.service.js";

const router = Router();


router.post("/signup", async (req, res, next) => {
    const data = await signup(req.body)
    console.log({ data }, "done ");
    return succsseResponse({
        res,
        statusCode: 201,
        data
    });
});
router.post("/login", async (req, res, next) => {
    const data = await login(req.body)
    console.log({ data }, "done ");
     
    
    return succsseResponse({
        message: "Login successful",
        res,
        statusCode: 200,
        data
    });
});


export default router;